package OOP.OOPBasics.Encapsulation.Exercises.Task3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String name = sc.nextLine();
        int age = Integer.parseInt(sc.nextLine());

        try {
            Chicken chk = new Chicken(name, age);

            System.out.printf("Chicken %s (age %d) can produce %.0f eggs per day.", chk.getName(), chk.getAge(), chk.getPerDay());
        } catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
}
