package OOP.OOPBasics.Encapsulation.Exercises.Task3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String name = sc.nextLine();
        int age = Integer.parseInt(sc.nextLine());

        try {
            Chicken chk = new Chicken(name, age);

            System.out.println(chk.toString());
        } catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
}
