package OOP.OOPBasics.Polimorphism.Lab.Shapes;

public class Main {
    public static void main(String[] args) {

    }
}
